//
// Created by Ben on 9/22/2015.
//

#include "node1.h"

#ifndef CLASS_150921_CHECK_LISTS_H
#define CLASS_150921_CHECK_LISTS_H

typedef main_savitch_5::node *nodep;

void check_list1(nodep lst);
void check_list2(nodep lst);
void check_list2B(nodep lst);
void check_list2C(nodep lst);



#endif //CLASS_150921_CHECK_LISTS_H
